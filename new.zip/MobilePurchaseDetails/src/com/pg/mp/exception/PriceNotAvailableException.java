package com.pg.mp.exception;

public class PriceNotAvailableException extends RuntimeException {
	public PriceNotAvailableException(String msg)
	{
		super(msg);
	}

}
