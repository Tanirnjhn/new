package com.cg.mp.bean;

import java.time.LocalDate;

public class Customer {
	
	//Customer Attributes
	
	private String custName;
	private String Custmail;
	private int purchaseId;
	private String phoneNum;
	private LocalDate date;
	private int mobileId;
	
	
	//Getter and Setter Method
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustmail() {
		return Custmail;
	}
	public void setCustmail(String custmail) {
		Custmail = custmail;
	}
	public int getPurchaseId() {
		return (int) Math.random();
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	// Default Constructor
	public Customer() {
		super();
	}
	
	// Parameterized Constructor
	
	public Customer(String custName, String custmail, int purchaseId, String phoneNum, LocalDate date, int mobileId) {
		super();
		this.custName = custName;
		Custmail = custmail;
		this.purchaseId = purchaseId;
		this.phoneNum = phoneNum;
		this.date = date;
		this.mobileId = mobileId;
	}
	
	// toString Method
	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", Custmail=" + Custmail + ", purchaseId=" + purchaseId
				+ ", phoneNum=" + phoneNum + ", date=" + date + ", mobileId=" + mobileId + "]";
	}
	public void put(int mobileId2, Customer cusMap) {
		
	}
	
}
