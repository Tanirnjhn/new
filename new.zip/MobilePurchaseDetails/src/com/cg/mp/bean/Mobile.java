package com.cg.mp.bean;

public class Mobile {
	// Attributes of mobile
	private int mobileId;
	private int mobQuantity;
	private float mobPrice;
	private  String mobName;
	
	//Getter And Setter Methods
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public int getMobQuantity() {
		return mobQuantity;
	}
	public void setMobQuantity(int mobQuantity) {
		this.mobQuantity = mobQuantity;
	}
	public float getMobPrice() {
		return mobPrice;
	}
	public void setMobPrice(float mobPrice) {
		this.mobPrice = mobPrice;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	
	//Default Constructor
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	// Parameterized Constructor
	public Mobile(int mobileId, int mobQuantity, float mobPrice, String mobName) {
		super();
		this.mobileId = mobileId;
		this.mobQuantity = mobQuantity;
		this.mobPrice = mobPrice;
		this.mobName = mobName;
	}
	
	// toString Method
	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mobQuantity=" + mobQuantity + ", mobPrice=" + mobPrice + ", mobName="
				+ mobName + "]";
	}
	
	

}
