package com.cg.mp.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Mobile;
import com.cg.mp.repository.IMobileRepository;
import com.cg.mp.repository.MobileRepoImplements;
import com.pg.mp.exception.InvalidCustNameException;
import com.pg.mp.exception.InvalidMailException;
import com.pg.mp.exception.InvalidMobException;
import com.pg.mp.exception.InvalidPhoneException;
import com.pg.mp.exception.NotPurchaseException;
import com.pg.mp.exception.PriceNotAvailableException;

public class MobileImplements implements IMobile{
    //Mobile mob=new Mobile();
	 Map<Integer, Mobile> hm; 
//IMobileRepository repo = new MobileRepoImplements(hm);
IMobileRepository repo = new MobileRepoImplements();
	
	/*public MobileImplements(Map<Integer,Mobile> hm)
	{
	    repo=new MobileRepoImplements(hm);
	}*/
	
	public MobileImplements(IMobileRepository repo)
	{
		super();
		this.repo=repo;
	}
	
	public MobileImplements()
	{
		
	}
	
	@Override
	public Map<Integer, Mobile> view()
	{
		return repo.showMobDetails();
	}
	
	@Override
	public Map<Integer,Mobile> search(float mobprice1)
	{
	   if(IncorrectPrice(mobprice1))
			repo.findByPrice(mobprice1);
       return hm;
	}
	
	@Override
	public void purchaseOrNot(int mobileId, int mobQuantity) {
		if(purchase(mobQuantity))
			repo.updateQuanity(mobileId,mobQuantity);	
		else
			throw new NotPurchaseException("User do not want to purchase");
		   
	}
	@Override
	public Customer insert(String custName, String custMail, int purchaseId, String phoneNum, LocalDate date,int mobileId) {
		Customer cus=null;
		cus=new Customer(custName,custMail,purchaseId,phoneNum,date,mobileId);
		if(IsVaildId(mobileId) && IsValidCustName(custName) && IsValidMail(custMail) && IsValidPhone(phoneNum)) 
              repo.add(cus);
		return cus;
	}
	

	@Override
//	public Mobile view(int mobileId)
//	{
//		if(IsVaildId(mobileId))
//			if(repo.IsfindId(mobileId))
//				repo.showMobDetails(mobileId);
//			else 
//			{
//				throw new NotPurchaseException("We dont have mobile of given Id");
//			}
//	    return mob;
//	}
	

	
/*	boolean IsPurchase(purchaseId)
		if(purchaseId==false)
			throw new NotPurchaseException("Customer do not want to purchase");
		return true;			
	}*/
	public boolean IsVaildId (int mobId)
	{
		if(!Integer.toString(mobId).matches("[0-9]{4}"))
            throw new InvalidMobException("Mobile Id should Be greater than 4 digit");
		return true;
	}
    boolean IsValidCustName(String custName)
    {
    	if(!custName.matches("[A-Z][a-zA-Z]{1,20}"))
    			throw new InvalidCustNameException("Customer Name Should be of maximum length 20 only and first leeter should be capital ");
    	return true;
    }
    boolean IsValidMail(String mail)
    {
        if(!(mail.matches("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$")))
        	throw new InvalidMailException("Invalid Mail Id");
        return true;
    }
    boolean IsValidPhone(String phoneNum)
    {
    	if(!phoneNum.matches("[1-9][0-9]{9}"))
    		throw new InvalidPhoneException("Phone number Should be of 10 digits only");
    	return true;
    	
    }
    boolean purchase(int quantity)
    {
    	if(quantity==0)
    		return false;
    	return true;
    }
   boolean IncorrectPrice(float mobprice1)
   {
	   if(mobprice1<10000)
		   throw new PriceNotAvailableException("Range should be greater than 10000");
	   return true;
   }
	

	
    
}
